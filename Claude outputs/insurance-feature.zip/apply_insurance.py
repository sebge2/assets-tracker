"""Branche l'écran « Assurances & pensions » dans assets-tracker.

À lancer depuis la racine du dépôt : `python3 apply_insurance.py` (après avoir copié
`src/` et `tests/` de cette archive dans le dépôt). Chaque modification est idempotente.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path.cwd()


def patch(relative: str, old: str, new: str) -> None:
    path = ROOT / relative
    text = path.read_text(encoding="utf-8")
    if new in text:
        print(f"déjà fait : {relative}")
        return
    if text.count(old) != 1:
        raise SystemExit(f"ancre introuvable ou ambiguë dans {relative} :\n{old}")
    path.write_text(text.replace(old, new), encoding="utf-8")
    print(f"modifié   : {relative}")


def append(relative: str, marker: str, block: str) -> None:
    path = ROOT / relative
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print(f"déjà fait : {relative}")
        return
    path.write_text(text.rstrip("\n") + "\n" + block, encoding="utf-8")
    print(f"complété  : {relative}")


SCHEMA = """
-- Assurances & pensions (épargne-pension, assurance groupe) : hors portefeuille, pas de cours.
-- La valeur est celle du dernier relevé ; chaque relevé garde la valeur projetée à la retraite,
-- d'où l'historique des projections (`domain/insurance.py`).
CREATE TABLE IF NOT EXISTS insurance_contracts (
    id              INTEGER PRIMARY KEY,
    kind            TEXT NOT NULL CHECK (kind IN ('PENSION_SAVINGS', 'GROUP_INSURANCE')),
    name            TEXT NOT NULL,
    insurer         TEXT NOT NULL,
    contract_number TEXT,
    opened_on       TEXT NOT NULL,            -- ISO 8601
    retirement_on   TEXT,
    ceiling         TEXT                      -- plafond annuel (épargne-pension), Decimal en euros
);

CREATE TABLE IF NOT EXISTS insurance_payments (
    id          INTEGER PRIMARY KEY,
    contract_id INTEGER NOT NULL REFERENCES insurance_contracts(id) ON DELETE CASCADE,
    paid_on     TEXT NOT NULL,
    amount      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_insurance_payments_contract
    ON insurance_payments(contract_id, paid_on);

CREATE TABLE IF NOT EXISTS insurance_statements (
    id              INTEGER PRIMARY KEY,
    contract_id     INTEGER NOT NULL REFERENCES insurance_contracts(id) ON DELETE CASCADE,
    recorded_on     TEXT NOT NULL,
    current_value   TEXT NOT NULL,
    projected_value TEXT,                     -- NULL si le relevé ne donne pas de projection
    UNIQUE (contract_id, recorded_on)
);
"""

append("src/assets_tracker/db/schema.sql", "insurance_contracts", SCHEMA)

patch(
    "src/assets_tracker/db/connection.py",
    "    if version < 3:\n        _migrate_to_3(conn)\n",
    "    if version < 3:\n        _migrate_to_3(conn)\n    if version < 4:\n        _migrate_to_4(conn)\n",
)
append(
    "src/assets_tracker/db/connection.py",
    "def _migrate_to_4",
    '''

def _migrate_to_4(conn: Any) -> None:
    """Assurances & pensions : les tables `insurance_*` viennent de `schema.sql` (rien à copier)."""
    conn.execute("PRAGMA user_version = 4")
''',
)

patch(
    "src/assets_tracker/ui/icons.py",
    '    "stock": ',
    '    "insurance": \'<path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/>\'\n'
    '    \'<path d="M9 12l2.2 2.2L15.5 10"/>\',\n    "stock": ',
)

MW = "src/assets_tracker/ui/main_window.py"
patch(
    MW,
    "from assets_tracker.db.term_note_repository import TermNoteRepository\n",
    "from assets_tracker.db.insurance_repository import InsuranceRepository\n"
    "from assets_tracker.db.term_note_repository import TermNoteRepository\n",
)
patch(
    MW,
    "from assets_tracker.ui.term_notes_page import TermNotesPage\n",
    "from assets_tracker.ui.insurance_page import InsurancePage\n"
    "from assets_tracker.ui.term_notes_page import TermNotesPage\n",
)
patch(
    MW,
    "        term_note_repository = TermNoteRepository(database)\n",
    "        term_note_repository = TermNoteRepository(database)\n"
    "        insurance_repository = InsuranceRepository(database)\n",
)
patch(
    MW,
    "        self.term_notes_page = TermNotesPage(term_note_repository, exposure=exposure_repository)\n",
    "        self.term_notes_page = TermNotesPage(term_note_repository, exposure=exposure_repository)\n"
    "        self.insurance_page = InsurancePage(insurance_repository)  # hors portefeuille\n",
)
patch(
    MW,
    "        self._stack.addWidget(self.term_notes_page)\n",
    "        self._stack.addWidget(self.term_notes_page)\n"
    "        self._stack.addWidget(self.insurance_page)\n",
)
patch(
    MW,
    '                ("Bons de caisse", "term_note"),\n',
    '                ("Bons de caisse", "term_note"),\n'
    '                ("Assurances & pensions", "insurance"),\n',
)
patch(MW, "InstrumentType.STOCK: (6, self.stocks_page),", "InstrumentType.STOCK: (7, self.stocks_page),")
patch(
    MW,
    "        elif index == 6:\n            self.stocks_page.refresh()\n",
    "        elif index == 6:\n            self.insurance_page.refresh()\n"
    "        elif index == 7:\n            self.stocks_page.refresh()\n",
)

TEST = "tests/test_projection_page.py"
patch(
    TEST,
    '        "Obligations",\n        "Actions",\n',
    '        "Obligations",\n        "Bons de caisse",\n        "Assurances & pensions",\n        "Actions",\n',
)
patch(
    TEST,
    "    qtbot.mouseClick(window._nav_buttons[7], Qt.MouseButton.LeftButton)\n",
    "    qtbot.mouseClick(window._nav_buttons[8], Qt.MouseButton.LeftButton)\n",
)
patch(
    TEST,
    "    assert window._nav_buttons[7].isChecked()\n",
    "    assert window._nav_buttons[8].isChecked()\n",
)

AGENTS = """
- **Écran Assurances & pensions** (`ui/insurance_page.py`, logique pure `domain/insurance.py`, accès `db/insurance_repository.py`) : deux types seulement, épargne-pension (`PENSION_SAVINGS`, plafond annuel facultatif) et assurance groupe (`GROUP_INSURANCE`, date de retraite facultative). Tables `insurance_contracts`, `insurance_payments` (versements) et `insurance_statements` (relevés : date, valeur actuelle, valeur projetée facultative ; unique par contrat et date, `save_statement` remplace un relevé de même date), créées par `schema.sql`, migration 4 (`user_version`). **Ces contrats ne sont jamais dans le portefeuille** : ce ne sont pas des `assets`, `PortfolioPage` ne les connaît pas (totaux, répartitions et exposition les ignorent). Valeur = dernier relevé saisi à la main ; total versé = somme des versements. **Historique des valeurs projetées** : chaque « Actualiser la projection… » ajoute un relevé ; `projection_history` les liste du plus récent au plus ancien avec l'écart (montant et %) avec la projection précédente, et la fiche les trace (`_ProjectionChart`). Un relevé de plus d'un an (`STALE_DAYS`) déclenche le bandeau d'alerte et le badge « à actualiser ». Jauge du plafond : versé dans l'année civile courante / plafond. Menu latéral : entrée « Assurances & pensions » à l'index 6 (Actions passe à 7, Simulation à 8).
"""
append("AGENTS.md", "Écran Assurances & pensions", AGENTS)
